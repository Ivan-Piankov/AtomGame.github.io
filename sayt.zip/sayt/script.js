const recommendationsSection = document.getElementById("recommendations");

games.forEach(game => {
    const gameDiv = document.createElement("div");
    gameDiv.classList.add("game");

    const title = document.createElement("h3");
    title.textContent = game.title;

    const image = document.createElement("img");
    image.src = game.image;
    image.alt = game.title;

    const description = document.createElement("p");
    description.textContent = game.description;

    gameDiv.appendChild(title);
    gameDiv.appendChild(image);
    gameDiv.appendChild(description);

    recommendationsSection.appendChild(gameDiv);
});